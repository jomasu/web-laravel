@extends('layouts.layout')

<html>
<p>Hola mundo</p>
</html>