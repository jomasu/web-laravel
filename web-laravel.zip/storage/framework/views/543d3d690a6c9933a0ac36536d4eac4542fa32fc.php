<?php $__env->startSection('body'); ?>

 
 <section class="container">
 <?php $__currentLoopData = $producto_buscado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="product-image-wrapper single-products ">
        <article class="col-md-2">
            <img src="<?php echo e($producto->photopath_slot1); ?>" alt="" width="100" height="100">
        </article>
        <article class="col-md-2 productinfo text-center"><h3><br><?php echo e($producto->name); ?></h3></article>
        <article class="col-md-4 productinfo text-center"><br><?php echo e($producto->description); ?><br></article>
        <article class="col-md-2 productinfo text-center"><br><h2>$<?php echo e($producto->price); ?></h2><br></article><br>
        <article class="col-md-2 productinfo text-center">
         
            <a class="btn btn-primary" href="/shop/<?php echo e($producto->id); ?>">Ver Producto</a>    
            <br>
        </article>
        
    
    <hr>
    </div>
 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </section>


 <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>