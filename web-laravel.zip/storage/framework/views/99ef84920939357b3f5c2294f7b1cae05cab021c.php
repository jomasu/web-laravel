<?php $__env->startSection('title', 'shop'); ?>

<!--Contenido de la página-->
<?php $__env->startSection('body'); ?>
<section id="advertisement">
		<div class="container">
			<img src="images/shop/advertisement.jpg" alt="" />
		</div>
	</section>
	
	<section>
		<div class="container">
				<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				
				<div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
                        <h2 class="title text-center">Features Items</h2>
                        

                   
					   <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="<?php echo e($product->photopath_slot1); ?>" alt="" />
											<h2>$<?php echo e(number_format($product->price,2,',','.')); ?></h2>
											<p><?php echo e($product->name); ?></p>

										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>$<?php echo e(number_format($product->price,2,',','.')); ?></h2>
												<p><?php echo e($product->name); ?></p>

												<?php echo Form::open(['route'=>'products.addToCart','method'=>'POST']); ?>	
												<?php echo csrf_field(); ?>
												
												<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
												<input type="hidden" name="stock" value="1">	
												<button type="submit" href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Añadir a carrito</button>
												<?php echo Form::close(); ?>

											</div>
										</div>
										<img src="<?php echo e(asset('img/home/new.png')); ?>" class="new" alt="" />
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="/shop/<?php echo e($product->id); ?>"><i class="fa fa-plus-square"></i>Ver Producto</a></li>
										
									</ul>
								</div>
								
							</div>
							
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					


						
						
						<ul class="pagination">
							<?php echo e($products->render()); ?>

						</ul>
					</div><!--features_items-->
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<!--Footer de la página-->
<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>