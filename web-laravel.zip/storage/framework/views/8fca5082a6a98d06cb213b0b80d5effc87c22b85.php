<?php $__env->startSection('title', 'Electronicos y perifericos'); ?>

<!--Slider-->
<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<!--Contenido de la página-->
<?php $__env->startSection('body'); ?>
	<?php echo $__env->make('body', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<!--Footer de la página-->
<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>