<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>T fire - <?php echo $__env->yieldContent('title'); ?></title> 

    <!-- code CSS-->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
	<!--<link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">-->
    <link href="<?php echo e(asset('css/prettyPhoto.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/price-range.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet">
	<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    
    
</head>
	<body>



	<header id="header"><!--header-->

			<div>
				<?php echo $__env->make('layouts.menutop', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->make('layouts.navmiddle', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				
			</div>

	</header><!--/header-->

		<?php echo $__env->yieldSection(); ?>

		<div>
		
			<?php echo $__env->yieldContent('content'); ?>
		</div>

		<div>
			<?php echo $__env->yieldContent('body'); ?>
		</div>

		<div>
			<?php echo $__env->yieldContent('footer'); ?>
		</div>    



	<!-- code javascript-->

	<script src="<?php echo e(asset('js/jquery.js')); ?>" defer></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" defer></script>
	<script src="<?php echo e(asset('js/jquery.scrollUp.min.js')); ?>" defer></script>
	<script src="<?php echo e(asset('js/price-range.js')); ?>" defer></script>
	<script src="<?php echo e(asset('js/jquery.prettyPhoto.js')); ?>" defer></script>
	<script src="<?php echo e(asset('js/main.js')); ?>" defer></script>
	<script src="<?php echo e(asset('js/preview.js')); ?>" defer></script>
	

	</body>
</html>