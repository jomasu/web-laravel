<div class="row">
	<div class="col-sm-3">
		<div class="left-sidebar">
			<h2>Categorias</h2>
				<div class="panel-group category-products" id="accordian"><!--category-productsr-->
						
					<div class="panel panel-default">


						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordian" href="#sportswear">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											<?php echo e($categorie->name); ?>

									</a>
								</h4>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							    <br>
				    
		        </div><!--/category-products-->
        </div>			
		<div class="brands_products"><!--brands_products-->
							<h2>Marcas</h2>
			<div class="brands-name">
				<ul class="nav nav-pills nav-stacked">
					<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>		
						<li><a href="#"> <span class="pull-right">(50)</span><?php echo e($brand->name); ?></a></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
				</ul>
			</div>
		</div><!--/brands_products-->
						
						
						
						
					
	</div>
</div>