<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-md-4 clearfix">
						<div class="logo pull-left">
							<a href="/"><img src="<?php echo e(asset('img/home/tfire.png')); ?> " alt="" /></a>
						</div>
					</div>
					<div class="col-md-8 clearfix">
						<div class="shop-menu clearfix pull-right">
							<ul class="nav navbar-nav">
								<li><a href=""><i class="fa fa-user"></i> Nosotros</a></li>
								<li><a href="<?php echo e(route('cart')); ?>"><i class="fa fa-shopping-cart"></i> Carrito</a></li>

							  <?php if(Route::has('login')): ?>
								  <?php if(auth()->guard()->check()): ?>
								<li class="dropdown"><a ><i class="fa fa-lock"></i> Bienvenido <span class="name-user"><?php echo e(Auth::user()->name); ?></span></a>
								<ul role="menu" class="sub-menu">
										<li ><a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

									</a>
									<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
								</li>
									</ul>
								</li>
								 <?php else: ?>
								 <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
								 <?php endif; ?>
							<?php endif; ?>

							


							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->